#ifndef _NORME_H_
#define _NORME_H_

#include <math.h>
#include "type.h"

float square(float x);

float norme(Vecteur v);
#endif // !_NORME_H_