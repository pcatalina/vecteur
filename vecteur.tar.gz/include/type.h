#ifndef _TYPE_H_
#define _TYPE_H_

typedef struct
{
	float x;
	float y;
	float z;
}Vecteur;

#endif // !_TYPE_H_
