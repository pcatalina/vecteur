#ifndef _PRODUIT_H_
#define _PRODUIT_H_

#include "type.h"

float produitScalaire(Vecteur v1, Vecteur v2);

Vecteur produitVectoriel(Vecteur v1, Vecteur v2);
#endif // !_PRODUIT_H_